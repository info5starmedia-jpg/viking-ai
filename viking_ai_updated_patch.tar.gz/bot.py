# =========================
# Viking AI — bot.py
# PART 1 / 4
# =========================

import os
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import asyncio
import logging
from dotenv import load_dotenv

import discord
from discord import app_commands

from orchestrator_v2 import run_llm_analysis
from agents.spotify_agent import get_spotify_profile
from agents.youtube_agent import get_youtube_profile
from agents.tiktok_agent import get_tiktok_stats
from agents.artist_resolver import resolve_artist
from agents.artist_rating_engine import rate_artist, stars_to_emoji
from agents.demand_heatmap import top_cities_for_artist
from agents.sellout_probability_engine import score_sellout_probability
from agents.tour_brain_v4 import get_event_intel
from agents.tour_news_agent_v3 import get_tour_news
from agents.seo_agent_v2 import run_seo_audit
from agents.tavily_agent import search_news

from ticketmaster_agent_v2 import search_events_for_artist, get_event_details

import verified_fan_monitor
import tour_scan_monitor

# ---------- ENV ----------
load_dotenv()

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
VERIFIED_FAN_ALERT_CHANNEL_ID = int(
    os.getenv("VERIFIED_FAN_ALERT_CHANNEL_ID", "0")
)

if not DISCORD_TOKEN:
    raise RuntimeError("DISCORD_TOKEN missing")

# ---------- LOGGING ----------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("viking_ai")

# ---------- DISCORD ----------
intents = discord.Intents.default()
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)

# =========================
# PART 2 / 4 — Core Commands
# =========================

@tree.command(name="status", description="System health check")
async def status_cmd(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)

    status_lines = [
        "🩺 **Viking AI Status**",
        "",
        "• Discord: ✅ Online",
        f"• Spotify: {'✅' if get_spotify_profile else '❌'}",
        f"• YouTube: {'✅' if get_youtube_profile else '❌'}",
        f"• OpenAI: {'✅' if os.getenv('OPENAI_API_KEY') else '❌'}",
        f"• Gemini: {'✅' if os.getenv('GEMINI_API_KEY') else '⚠️'}",
        "• Touring Brain v4: ✅",
        f"• Verified Fan Monitor: {'✅' if VERIFIED_FAN_ALERT_CHANNEL_ID else '⚠️'}",
    ]

    await interaction.followup.send("\n".join(status_lines))


@tree.command(name="news_now", description="Latest tour news for an artist")
@app_commands.describe(artist="Artist name")
async def news_cmd(interaction: discord.Interaction, artist: str):
    await interaction.response.defer()

    news = await asyncio.to_thread(get_tour_news, artist)
    await interaction.followup.send(news[:1900])

# =========================
# PART 3 / 4 — Intel
# =========================

@tree.command(name="intel", description="Deep tour intelligence for an artist")
@app_commands.describe(artist="Artist name")
async def intel_cmd(interaction: discord.Interaction, artist: str):
    await interaction.response.defer()

    try:
        # 1) Resolve canonical artist identity
        resolved = await asyncio.to_thread(resolve_artist, artist)
        canonical = resolved.get("name") or artist

        # 2) Core socials
        spotify = resolved.get("spotify") or get_spotify_profile(canonical)
        youtube = resolved.get("youtube") or get_youtube_profile(canonical)

        # TikTok agent is async
        try:
            tiktok = await get_tiktok_stats(canonical)
        except Exception:
            tiktok = {"error": "tiktok_fetch_failed"}

        # 3) Artist rating (1–5 stars)
        rating = rate_artist(spotify=spotify, youtube=youtube, tiktok=tiktok)
        stars = stars_to_emoji(rating.get("stars", 1))

        # 4) Best cities (demand heatmap)
        cities = await asyncio.to_thread(top_cities_for_artist, canonical, 8)

        event_shell = {
            "artist": canonical,
            "spotify": spotify,
            "youtube": youtube,
            "tiktok": tiktok,
        }

        # 5) Pull upcoming events (Ticketmaster) and compute per-event sellout probability
        tm_events = []
        try:
            tm_events = await search_events_for_artist(canonical)
        except Exception as e:
            logger.warning("Ticketmaster search failed: %s", e)

        # Map city weights from heatmap
        city_weight_map = {c: w for (c, w) in (cities or [])}

        scored_events = []
        for e in (tm_events or [])[:12]:
            city = e.get("city") or ""
            city_weight = city_weight_map.get(city)
            scored = score_sellout_probability(
                {
                    "name": e.get("name"),
                    "city": city,
                    "venue": e.get("venue"),
                    "artist": canonical,
                },
                spotify=spotify,
                youtube=youtube,
                city_weight=int(city_weight) if city_weight is not None else None,
            )
            scored_events.append({"event": e, "score": scored})

        # 6) Keep your existing Touring Brain narrative (optional)
        intel = await get_event_intel(event_shell, canonical)

        prompt = (
            f"Artist: {canonical}\n"
            f"Spotify: {spotify}\n"
            f"YouTube: {youtube}\n"
            f"TikTok: {tiktok}\n"
            f"Artist rating: {rating}\n"
            f"Best cities: {cities}\n"
            f"Intel: {intel}\n"
            "Give a concise touring analysis."
        )

        analysis = await asyncio.to_thread(run_llm_analysis, prompt)

        # 7) Format output
        tm_official_site = ((resolved.get("ticketmaster") or {}).get("official_site") or "").strip()
        tm_attraction_url = ((resolved.get("ticketmaster") or {}).get("attraction_url") or "").strip()

        def _fmt_num(n: int) -> str:
            try:
                return f"{int(n):,}"
            except Exception:
                return str(n)

        spotify_block = (
            f"🎧 Spotify: popularity **{spotify.get('popularity', '—')}**/100 • followers **{_fmt_num(spotify.get('followers', 0))}**\n"
            f"• {spotify.get('url','') or ''}"
        ).strip()

        youtube_block = (
            f"📺 YouTube: subs **{_fmt_num(youtube.get('subs_estimate', 0))}** • momentum **{youtube.get('momentum', '—')}**/100"
        ).strip()

        if tiktok.get("error"):
            tiktok_block = "📱 TikTok: (not configured — set `TIKTOK_API_KEY`)"
        else:
            tiktok_block = (
                f"📱 TikTok: hashtag **#{tiktok.get('name','')}** • views **{_fmt_num(tiktok.get('views', 0))}** • trend **{tiktok.get('trend','')}**"
            ).strip()

        best_cities_block = "\n".join([f"• {c} (demand {w})" for c, w in (cities or [])]) or "• (no city data yet)"

        # Top 8 scored events by probability
        scored_events.sort(key=lambda x: (x.get('score') or {}).get('sellout_probability', 0), reverse=True)
        events_lines = []
        for row in scored_events[:8]:
            e = row["event"]
            s = row["score"]
            prob = s.get("sellout_probability", 0)
            events_lines.append(
                f"• **{e.get('date','')}** — {e.get('city','')} @ {e.get('venue','')} — **{prob}%**  \n  🎟 {e.get('url','')}"
            )
        events_block = "\n".join(events_lines) if events_lines else "(No upcoming Ticketmaster events found.)"

        links_block = "\n".join([
            f"🌐 Official site: {tm_official_site}" if tm_official_site else "🌐 Official site: (not found)",
            f"🎫 Ticketmaster artist: {tm_attraction_url}" if tm_attraction_url else "🎫 Ticketmaster artist: (not found)",
            "🔐 Verified Fan signup: https://verifiedfan.ticketmaster.com",
        ])

        message = (
            f"📊 **Viking AI Intel — {canonical}**\n"
            f"{stars} **{rating.get('label','')}** (score {rating.get('score','—')}/100)\n\n"
            f"{spotify_block}\n{youtube_block}\n{tiktok_block}\n\n"
            f"🔥 **Best Demand Cities**\n{best_cities_block}\n\n"
            f"🏟 **Sellout Probability (Top Events)**\n{events_block}\n\n"
            f"🔗 **Links**\n{links_block}\n\n"
            f"🧠 **Viking Analysis:**\n{analysis}"
        )

        await interaction.followup.send(message[:1900])

    except Exception as e:
        logger.exception("Intel command error")
        await interaction.followup.send(
            f"❌ Touring Brain error: `{e}`",
            ephemeral=True
        )

# =========================
# PART 4 / 4 — Startup
# =========================

@client.event
async def on_ready():
    global _tour_scan_started
    if '_tour_scan_started' not in globals():
        _tour_scan_started = True
        import threading
        channel_id = int(os.getenv('TOUR_SCAN_CHANNEL_ID','0') or 0)
        t = threading.Thread(target=tour_scan_monitor.poll_tour_scan_loop, args=(client, channel_id if channel_id else None), daemon=True)
        t.start()
        logger.info('Tour scan background thread started.')

    await tree.sync()
    logger.info("Slash commands synced.")
    logger.info(f"Logged in as {client.user}")

    # Start Verified Fan monitor ONLY if channel configured
    if VERIFIED_FAN_ALERT_CHANNEL_ID:
        asyncio.create_task(
            verified_fan_monitor.poll_verified_fan_loop(
                client,
                VERIFIED_FAN_ALERT_CHANNEL_ID
            )
        )


def main():
    client.run(DISCORD_TOKEN)


if __name__ == "__main__":
    main()

